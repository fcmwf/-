
rm -rf ./base-port ./functest ./mytest

ln -s ../software/base-port base-port
ln -s ../software/functest functest
ln -s ../software/mytest mytest