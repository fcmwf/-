
rm -rf ./mycpu ./script ./sim.cpp ./base ./device-test


ln -s ../simulator/IP/mycpu mycpu
ln -s ../simulator/script script
ln -s ../simulator/sim/sim.cpp sim.cpp
ln -s ../software/base-port/base base
ln -s ../software/device-test device-test
