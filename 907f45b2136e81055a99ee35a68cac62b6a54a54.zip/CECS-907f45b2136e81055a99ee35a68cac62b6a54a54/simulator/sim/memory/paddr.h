#ifndef __PADDR_H__
#define __PADDR_H__
extern void pmem_read();
extern void pmem_write();
#endif