
rm -rf ./mycpu ./main.S ./sim


ln -s ../simulator/IP/mycpu mycpu
ln -s ../software/picotest/src/main.S main.S
ln -s ../simulator/sim sim
