
rm -rf ./sim.cpp ./build.cpp

ln -s ../simulator/sim/sim.cpp sim.cpp
ln -s ../simulator/sim/build.cpp build.cpp
ln -s ../simulator/sim/main.cpp main.cpp
ln -s ../simulator/sim/sdb sdb
